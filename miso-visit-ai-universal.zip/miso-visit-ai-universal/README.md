# 미소방문 AI 범용 패키지

버전: 2026-09-12

이 패키지는 미소방문(Moving Concierge, MVC)의 서비스 구조, 운영, KPI, SQL, 정책, 손익, 확장과 의사결정 이력을 Claude, Gemini, Cursor, GPT 계열 AI에서 공통으로 사용하기 위한 지식 패키지입니다.

## 가장 빠른 시작

사용할 AI에 맞는 안내서를 먼저 읽습니다.

- Claude: `README_CLAUDE.md`
- Gemini: `README_GEMINI.md`
- Cursor: `README_CURSOR.md`
- GPT·ChatGPT: `README_GPT.md`

각 플랫폼에 `SYSTEM_PROMPT.md`를 지침으로 등록하고 `knowledge/`의 문서를 지식 파일로 추가하면 됩니다. 연결 기능이 없는 환경에서는 `offline-mode.md`도 함께 적용합니다.

## 패키지 구성

| 경로 | 용도 |
| --- | --- |
| `SYSTEM_PROMPT.md` | 모든 AI에 공통으로 넣는 핵심 운영 지침 |
| `knowledge/` | 서비스·운영·지표·정책·확장·연혁·Source Map |
| `sources.md` | Google 원본과 Slack 채널 목록 |
| `connector-guide.md` | Live Source 연결 시 조회·검증 규칙 |
| `offline-mode.md` | 연결이 없을 때의 안전한 답변 방식 |
| `examples.md` | 설치 확인용 테스트 질문과 기대 동작 |
| `platforms/` | 플랫폼에 바로 복사할 수 있는 설정 파일 |
| `platforms/gpt/chatgpt-skill/` | ChatGPT/Codex용 원본 Skill 폴더 |

## 공통 운영 원칙

1. `현재`, `오늘`, `어제`, `최신`, 현재 인원·KPI·정책·R&R 질문은 연결된 원본을 먼저 조회합니다.
2. 원본에 접근하지 못하면 현재값이라고 단정하지 않고 마지막 확인 기준일을 밝힙니다.
3. 고정 문서에는 정의·규칙·과거 Snapshot만 유지합니다. 매일 바뀌는 숫자는 복사해 관리하지 않습니다.
4. Google Sheet 행이나 숫자, Slack Thread 내용이 갱신된 것만으로 패키지를 다시 만들 필요는 없습니다.
5. Source URL, Sheet 구조·컬럼 의미, KPI 정의, 정책 또는 우선순위가 바뀌면 패키지를 업데이트합니다.

## 신규입사자 권장 사용 순서

1. `knowledge/service-model.md`로 서비스와 고객 여정을 이해합니다.
2. `knowledge/operations-playbook.md`로 역할과 일일 운영을 익힙니다.
3. `knowledge/metrics-and-data.md`로 지표와 데이터 기준을 확인합니다.
4. 사용 AI의 README대로 설치합니다.
5. `examples.md`의 테스트 질문으로 답변 기준과 최신 소스 접근 여부를 확인합니다.

## 보안

이 패키지에는 API Key, Token, 비밀번호를 넣지 않습니다. 고객 전화번호, 주소, Chat 전문, CRM Row data는 업무상 필요한 최소 범위에서만 사용합니다. 외부 AI 서비스에 회사 자료를 업로드하기 전 조직의 보안·데이터 처리 정책과 계정 권한을 확인하세요.
