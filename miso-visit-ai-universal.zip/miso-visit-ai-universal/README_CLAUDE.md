# Claude에서 사용하는 방법

## 권장 방식: Claude Project

1. Claude에서 새 Project를 만들고 이름을 `미소방문 운영`으로 지정합니다.
2. Project Instructions에 `SYSTEM_PROMPT.md`의 내용을 붙여넣습니다.
3. Project Files에 `knowledge/`의 7개 문서와 `sources.md`, `connector-guide.md`, `offline-mode.md`를 추가합니다.
4. 조직에서 허용된 Google Workspace·Slack Connector가 있다면 연결하고 접근 권한을 확인합니다.
5. `examples.md`의 테스트 1, 2, 4를 실행합니다.

Claude Project의 Files는 여러 대화에서 지속적으로 참조할 수 있습니다. 업로드한 정적 파일은 원본 Google 문서와 자동 동기화된다고 가정하지 마세요. 연결된 원본을 읽을 수 없다면 문서를 다시 Export해 교체해야 합니다.

## Claude Code에서 사용

`platforms/claude/CLAUDE.md`를 작업 저장소 루트의 `CLAUDE.md`로 복사하고 이 패키지를 `docs/miso-visit/` 같은 경로에 둡니다. 경로를 변경하면 `CLAUDE.md` 안의 참조 경로도 함께 수정합니다.

## Live Source 판단

- Connector 사용 가능: `현재` 질문마다 원본을 다시 읽습니다.
- Connector 사용 불가: `offline-mode.md`를 따릅니다.
- Slack 링크만 있고 로그인·권한이 없음: 내용을 읽었다고 가정하지 않습니다.

## 공식 참고

- Claude 파일 업로드: https://support.claude.com/en/articles/8241126-upload-files-to-claude
- Claude Projects: https://support.claude.com/en/articles/9517075-what-are-projects
