# Cursor에서 사용하는 방법

## 권장 방식: Project Rule

1. 이 패키지 전체를 저장소의 `docs/miso-visit/`에 복사합니다.
2. `platforms/cursor/.cursor/rules/miso-visit-ops.mdc`를 저장소의 `.cursor/rules/`에 복사합니다.
3. 더 단순한 방식이 필요하면 `platforms/cursor/AGENTS.md`를 저장소 루트의 `AGENTS.md`로 사용합니다.
4. Rule 안의 `docs/miso-visit/` 경로가 실제 설치 위치와 같은지 확인합니다.
5. Agent Chat에서 `미소방문 최근 30일 계약률 쿼리 작성` 같은 질문으로 테스트합니다.

Project Rule은 저장소와 함께 버전 관리할 수 있습니다. `Apply Intelligently`에 해당하는 설정으로 만들어 미소방문 관련 작업에서만 불러오도록 구성했습니다. 모든 대화에 강제로 적용하려면 `alwaysApply: true`로 바꿀 수 있지만, 다른 개발 작업까지 영향을 받으므로 권장하지 않습니다.

## Live Source 연결

Cursor 자체가 문서 URL만 보고 사내 Google·Slack 내용을 항상 읽을 수 있는 것은 아닙니다. 조직에서 승인한 MCP/API를 연결하거나 최신 Export를 `docs/miso-visit/knowledge/`에 교체합니다. Credential을 Rule이나 저장소에 커밋하지 않습니다.

## 공식 참고

- Cursor Rules와 `AGENTS.md`: https://cursor.com/docs/rules
- Cursor Skills: https://cursor.com/docs/skills
