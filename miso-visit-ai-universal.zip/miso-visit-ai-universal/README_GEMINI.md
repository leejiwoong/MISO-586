# Gemini에서 사용하는 방법

## 권장 방식: Gem

1. Gemini 웹 앱의 `Gems`에서 새 Gem을 만들고 이름을 `미소방문 운영`으로 지정합니다.
2. Gem Instructions에 `SYSTEM_PROMPT.md`의 내용을 붙여넣습니다.
3. Knowledge에서 `knowledge/`의 문서와 `sources.md`, `connector-guide.md`, `offline-mode.md`를 추가합니다.
4. 가능하면 파일 업로드보다 Google Drive의 원본 문서를 Knowledge에 직접 추가합니다. Drive에서 추가한 파일은 원본 변경이 Gem에 반영되는 방식이므로 Live Source 유지에 유리합니다.
5. `examples.md`의 테스트 질문으로 확인합니다.

## Gemini CLI에서 사용

`platforms/gemini/GEMINI.md`를 프로젝트 루트에 복사하고 패키지를 `docs/miso-visit/`에 둡니다. 실제 경로에 맞게 문서 링크를 수정합니다.

## 주의

- Google Drive 원본 접근은 계정·Workspace 연결 및 조직 정책에 따라 달라집니다.
- Slack/HubSpot/Warehouse는 별도 Connector 또는 MCP/API가 없으면 자동 조회되지 않습니다.
- 단순 업로드 파일은 Snapshot으로 취급합니다.

## 공식 참고

- Gemini Gems 생성·Knowledge 파일 추가: https://support.google.com/gemini/answer/15146780
