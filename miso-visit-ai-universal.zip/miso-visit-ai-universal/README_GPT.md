# GPT·ChatGPT에서 사용하는 방법

## 방법 A — ChatGPT Project

1. ChatGPT에서 새 Project를 만들고 이름을 `미소방문 운영`으로 지정합니다.
2. Project settings의 Instructions에 `SYSTEM_PROMPT.md`를 붙여넣습니다.
3. Project Sources에 `knowledge/` 문서와 `sources.md`, `connector-guide.md`, `offline-mode.md`를 추가합니다.
4. 사용 가능한 경우 Google Drive 파일·폴더 링크와 Slack 채널 링크를 Project Source로 추가하고 연결 권한을 승인합니다.
5. `examples.md`로 테스트합니다.

Project에 Google Drive 앱을 연결했더라도 모든 내용이 사전 동기화된다고 가정하지 않습니다. 최신 질문에서는 실제 원본을 검색·조회했는지 확인합니다.

## 방법 B — Custom GPT

GPT Instructions에 `SYSTEM_PROMPT.md`를 넣고 Knowledge에 `knowledge/` 문서를 업로드합니다. 연결 Actions 또는 앱이 없다면 `offline-mode.md`를 반드시 포함합니다. 조직 외 공유 전 내부 데이터와 권한 범위를 확인합니다.

## 방법 C — ChatGPT/Codex Skill

`platforms/gpt/chatgpt-skill/` 폴더가 원본 `miso-visit-ops` Skill입니다. Skill 업로드를 지원하는 환경에서는 이 폴더를 ZIP으로 압축해 설치합니다. 이 범용 패키지의 AI별 README는 Skill 설치와 별개이며, 신규입사자의 실제 사용 환경에 맞는 방법을 선택하면 됩니다.

## 공식 참고

- ChatGPT Projects: https://help.openai.com/en/articles/10169521-chatgpt-projects
