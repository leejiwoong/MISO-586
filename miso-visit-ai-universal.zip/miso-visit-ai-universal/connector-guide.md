# Live Source 연결 가이드

## 연결 가능 환경

AI가 Google Drive·Sheets·Docs 또는 Slack Connector/MCP/API를 사용할 수 있으면 다음 순서로 조회합니다.

1. 질문 유형을 `knowledge/source-map.md`에서 찾습니다.
2. 해당 Tier 1 Source 원본을 읽습니다.
3. Slack 링크는 원문, 작성 시각, Thread의 후속 답변과 최종 합의를 확인합니다.
4. 숫자는 서비스, 기간, 분자·분모, 제외 조건, 갱신 시각을 검증합니다.
5. 충돌은 정의 차이, 갱신 시차, 필터 차이, 실제 변경으로 구분합니다.
6. 답변에 기준일과 Source 이름을 남깁니다.

## 연결별 역할

| 연결 | 주 용도 | 주의점 |
| --- | --- | --- |
| Google Drive/Sheets | KPI, Planner 현황, P&L, Weekly Report | Sheet 탭·수식·업데이트 시각 확인 |
| Slack | 최신 운영 합의, 사건, 담당자·기한 | 단일 메시지를 확정 정책으로 단정하지 않음 |
| HubSpot | CRM Stage, Sales Call, Closed Won | 속성 정의와 Warehouse 결제 이벤트 대조 |
| Warehouse/Redash | Row data, Funnel, 실시간 계약 | Query 갱신 지연과 스키마 확인 |

## 연결 실패 시

권한 오류나 연결 부재를 데이터가 없다는 뜻으로 해석하지 않습니다. `offline-mode.md`로 전환하고, 필요한 파일·탭·기간을 사용자에게 구체적으로 요청합니다. Credential을 요청하거나 문서에 저장하지 않습니다.

## 장기 권장 구조

여러 AI가 같은 최신 정보를 사용해야 하면 원본을 한 곳에 유지하고 각 AI를 Connector 또는 MCP/API 계층으로 연결합니다. 플랫폼별 지식 파일은 기준 지식과 Source Map만 가지며, 일별 수치를 복제하지 않습니다.
