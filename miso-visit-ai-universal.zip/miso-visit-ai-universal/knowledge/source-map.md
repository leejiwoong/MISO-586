# 원본 출처 지도

지식 기준일: 2026-09-12. 이 문서는 미소방문 질문에서 어떤 원본을 조회할지 정한다. **문서 내용은 Skill에 고정하지 않고 원본에서 다시 읽는 것을 기본값으로 한다.**

## 1. Source 계층

### Tier 0 — 사용자가 이번 대화에서 제공한 원본
직접 첨부한 파일, 링크, SQL 결과, 명시적 정정값. 해당 질문의 범위에서는 가장 높은 우선순위로 사용한다.

### Tier 1 — 공식 Live Source
Google Sheets/Docs/Slides, Slack, HubSpot 등 실제 업무에서 계속 갱신되는 원본. `현재/최신/오늘` 질문은 Tier 1을 반드시 확인한다.

### Tier 2 — Skill Reference
서비스 정의, 지표 정의, 정책 규칙, 데이터 모델, 과거 의사결정 등 자주 변하지 않는 기준 지식.

### Tier 3 — Snapshot
과거 시점의 수치나 조직 상태. 현재 원본에 접근할 수 없을 때만 기준일을 명시하고 사용한다.

## 2. 질문별 1차 원천

| 질문 | 1차 원천 | 보조 원천 | 검증 기준 |
|---|---|---|---|
| 일·주·월 핵심 실적, AQPR, 계약, 매출, GP | Google Sheet `daily number & Moving by Miso Metrics`, 특히 `superset` | 기간별 Metrics View, Warehouse Query | 서비스·기간·분모·필터를 함께 확인 |
| 플래너 생산성·현황·인원 | `[미소방문] Planner 현황`, `Planner_metrics` | `Moving_Conciege_Sync`, 운영 Slack | 재직/활성/프리랜서 여부와 기준일 구분 |
| 운영 R&R, Daily KPI | `Moving_Conciege_Sync` | `#service-moving-visit-ops` 최신 합의 Thread | 문서 수정일과 Slack 후속 합의 비교 |
| 공식 주간 실적 | `[Moving visit] Weekly Report (official)` | Metrics Sheet | Lead/Visit Cohort 분모 구분 |
| 사업성·P&L·서비스 비교 | `MVC vs MV_RFQ 사업성 비교 분석` | Metrics, Weekly Report | 가정값과 실제값 분리 |
| 채용·JD·역할 설계 | `JD 정리` | R&R 문서, 면접 원본 | 현재 조직 R&R과 채용 역할을 혼동하지 않음 |
| CRM·Sales Call | HubSpot Pipeline과 속성 | `#service-moving-mvos-chat`, Warehouse | CRM 상태와 실제 Chat·결제 이벤트 대조 |
| 견적 공급·제품 로직 | `#product-rfq`, 제품 문서 | `#service-moving`, 운영 Log | Pilot·배포·수동 운영 구분 |
| 정책·법률 | 최신 약관·법률 검토 문서 | 운영 안내·Marketing 문구 | 고객 권리·계약 구조 변경 시 법률 재검토 |
| 지역 확장 | 공식 오픈 문서·제품 설정 | Expansion 문서, Slack | Partner Coverage와 공식 오픈 구분 |
| 플래너 교육 | `미소방문 플래너 교육 전체 가이드_-September 2026` | 운영 R&R, 교육 Slack | 교육안과 실제 시행 규칙을 구분 |

## 3. 프로젝트에 등록된 핵심 Google Source

다음 Source는 이름 또는 URL로 식별한다. 연결된 프로젝트/Drive에서 원본을 읽고, 내용 자체를 Skill에 복제하지 않는다.

- `MVC vs MV_RFQ 사업성 비교 분석`
  - https://docs.google.com/spreadsheets/d/1zrn0ycaBjgJQMKGxNvyjTG3FnONJYT35yXIghXYqDy8
- `미소방문 플래너 교육 전체 가이드_-September 2026`
  - https://docs.google.com/presentation/d/1H6Rp3tOFwML49sOW7-cBPZwO5Ft01xspsAbhXP8rGTE
- `Planner_metrics`
  - https://docs.google.com/spreadsheets/d/1upVh8k1Vm2AUVAg9CZE74jHpR8GsRgNhTZQ5bcyevD8
- `JD 정리`
  - https://docs.google.com/spreadsheets/d/1kXTSfBUnpfjzckt-QV6u63giXYMEqJOrmRVP0p292Xc
- `[미소방문] Planner 현황`
  - https://docs.google.com/spreadsheets/d/1LwBeWsQe7qfWqMpcrFP1BX75A7Q6Nx8vhfgUfrbi7tg
- `Moving_Conciege_Sync`
  - https://docs.google.com/document/d/1y4d0ytvcFJm2Qa0zULkt_53I7YbFjW7_C4sams9bZ8c
- `[Moving visit] Weekly Report (official)`
  - https://docs.google.com/document/d/1I3J1rZ7z0tfveKGEfeH588s1CsUJEDhS9fzi6Aems2k

URL은 Source 식별용이다. 권한이 없거나 Connector가 연결되지 않은 환경에서는 접근 가능하다고 가정하지 않는다.

## 4. 핵심 Metrics Sheet

문서명: `daily number & Moving by Miso Metrics`

핵심 시트:

- `superset`: 일자·서비스 단위 원천 Import와 핵심 수치. 숫자 질문에서 가장 먼저 확인한다.
- `Moving by Miso Metrics(day)`, `Moving by Miso Metrics(week)`, `Moving by Miso Metrics(month)`: 기간별 표시 View.
- `Know your numbers(MVC)`, `cohort`, `MVC_cohort_rate`: 미소방문 Funnel·Cohort 분석.
- `Month(Daily Contract Rate)`, `Month(Contract Conversion Rate)`: 월별 계약률 View.
- `Excellent Operation`, `daily processing 관리,`: 운영 품질·Processing 관리.
- `Deals(hubspot)`, `Cross sell(hubspot)`: CRM과 Cross-sell 보조 데이터.

`superset`은 외부 Query Import와 Sheet 계산을 포함한다. XLSX Snapshot에서 Google 전용 함수가 `#NAME?`으로 보일 수 있으므로 Snapshot 재계산 결과만으로 원천 장애를 단정하지 않는다. Header, Source Query, 서비스 필터, 날짜 기준, 파생식을 함께 확인한다. 운영 AQPR은 Header 이름만 믿지 말고 같은 필터의 유효 견적수 ÷ 대상 Request 수로 검산한다.

## 5. Slack Live Source

핵심 채널:

| 채널 | 용도 |
|---|---|
| `#service-moving-visit-ops` | 핵심 운영, R&R, Daily Closing |
| `#service-moving` | 이사 서비스 공통 운영 |
| `#product-rfq` | 견적 제품, 자동화, Slot·Quote 로직 |
| `#service-moving-mvos-chat` | 고객 Chat과 반복 이슈 |
| `#service-moving-mvos-log` | 시스템·운영 Log |
| `#service-moving-alert` | 운영 Alert |

Slack permalink가 프로젝트 소스로 등록되거나 사용자가 링크를 제공하면 다음 순서로 확인한다.

1. 링크의 원문 메시지와 작성 시각을 확인한다.
2. Thread가 있으면 후속 답글과 최종 합의를 확인한다.
3. 같은 주제의 더 최신 공식 문서가 있는지 확인한다.
4. 메시지가 제안/질문인지 확정 의사결정인지 구분한다.
5. 사람 이름, 목표값, 날짜가 바뀌는 내용은 기준일을 함께 기록한다.

정책이나 KPI 변경은 단일 Slack 메시지만으로 확정하지 않는다. 원문 Thread, 결정권자, 후속 문서 반영 여부를 함께 본다.

## 6. 최신성 확인 절차

1. `오늘/현재/최신/어제/이번 주/이번 달` 또는 현재 인원·KPI·정책을 묻는지 판단한다.
2. 질문 유형에 맞는 Tier 1 Live Source를 조회한다.
3. 숫자는 원천 Sheet 또는 시스템의 날짜, 서비스, 분모, 제외 조건을 확인한다.
4. R&R과 운영 목표는 공식 문서와 더 최신 Slack 합의를 대조한다.
5. 출처 간 값이 다르면 `정의 차이 / 갱신 시차 / 필터 차이 / 실제 변경` 중 원인을 찾는다.
6. 답변에 기준일과 핵심 Source 이름을 명시한다.
7. 원본에 접근할 수 없으면 Snapshot 기준임을 밝히고 현재값처럼 표현하지 않는다.

## 7. Skill을 다시 만들어야 하는 경우

**재생성 불필요**
- Google Sheet에 행이 추가되거나 숫자가 바뀜
- Weekly Report 내용이 갱신됨
- Slack Thread에 새 운영 합의가 추가됨
- Planner 현황의 인원이 변경됨

**Skill 업데이트 필요**
- Source 문서명/URL/접근 경로가 바뀜
- 핵심 Sheet 탭 또는 컬럼의 의미가 바뀜
- KPI 정의, 분모, 제외 규칙이 바뀜
- 새로운 공식 Source가 추가되어 우선순위를 정해야 함
- 서비스 구조·법률·수수료 정책 등 기준 지식이 변경됨

## 8. 보안과 개인정보

- Sheet 수식·Import URL, Slack 메시지, 문서에 포함된 API Key, Token, 비밀번호를 답변·로그·Skill에 복사하지 않는다.
- Credential처럼 보이는 값을 발견하면 마스킹하고 삭제·회전을 권고한다.
- 고객 전화번호, 주소, 대화 전문, CRM Row는 업무상 필요한 최소 범위만 사용한다.
