# 오프라인 모드

Google Drive, Slack, HubSpot, Warehouse에 접근할 수 없는 AI는 다음 규칙을 적용합니다.

1. `knowledge/`는 2026-09-12 기준 Snapshot과 정의 문서로 사용합니다.
2. 현재 인원·오늘 KPI·최신 정책처럼 변동 가능한 질문에는 현재값을 단정하지 않습니다.
3. 답변 첫 부분에 `Live Source 미연결 — 마지막 지식 기준일 2026-09-12`를 표시합니다.
4. 최신 확인에 필요한 최소 자료를 구체적으로 요청합니다. 예: 문서 전체가 아니라 `Planner 현황`의 재직 상태 열과 수정일, Metrics Sheet의 기간·서비스·분자·분모.
5. 사용자가 최신 Export 파일을 제공하면 해당 파일을 그 질문의 Tier 0 원본으로 사용합니다.
6. Export 파일을 영구 최신 원본처럼 재사용하지 않고 Snapshot 날짜를 기록합니다.

## 권장 갱신 방식

- 가장 좋음: 원본 Google Drive 파일을 지식 Source로 연결
- 차선: 주기적으로 원본을 PDF/XLSX/CSV/Markdown으로 Export하여 교체
- 최소: `sources.md`의 원본 링크와 마지막 확인일을 유지하고 질문 때 파일을 요청

Google Sheet 숫자만 바뀌었다면 원본 연결 환경에서는 재설치가 필요 없습니다. 오프라인 환경에서는 새 Export로 교체해야 최신값을 반영할 수 있습니다.
