# 미소방문 프로젝트 지침

미소방문 관련 질문과 코드 작업에서는 먼저 `docs/miso-visit/SYSTEM_PROMPT.md`를 따르고, 질문에 필요한 문서만 `docs/miso-visit/knowledge/`에서 읽는다.

현재·최신 정보는 연결된 원본을 조회한다. 원본에 접근할 수 없으면 `docs/miso-visit/offline-mode.md`를 적용한다. 분석 요청만으로 외부 시스템을 변경하거나 메시지를 발송하지 않는다.
