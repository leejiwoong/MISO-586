# 미소방문 프로젝트 지침

미소방문 관련 요청에서는 `docs/miso-visit/SYSTEM_PROMPT.md`와 질문 유형에 맞는 `docs/miso-visit/knowledge/` 문서를 읽는다.

Athena/PrestoSQL, Funnel, CRM, Planner·Partner 운영의 회사 기준을 보존한다. 최신값은 Live Source로 검증하고, 연결이 없으면 `docs/miso-visit/offline-mode.md`를 적용한다. 분석 요청만으로 외부 액션을 실행하지 않는다.
