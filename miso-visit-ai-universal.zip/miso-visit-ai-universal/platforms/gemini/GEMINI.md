# 미소방문 프로젝트 지침

미소방문 관련 요청에는 `docs/miso-visit/SYSTEM_PROMPT.md`를 적용하고 `docs/miso-visit/knowledge/`의 관련 문서를 읽는다.

현재·최신 값은 연결된 Google Drive·Slack·CRM·Warehouse 원본으로 검증한다. 연결이 없으면 `docs/miso-visit/offline-mode.md`를 따른다. Credential을 문서나 코드에 저장하지 않는다.
