# 미소방문 Live Source 목록

## Google Source

| 문서 | 용도 | 링크 |
| --- | --- | --- |
| MVC vs MV_RFQ 사업성 비교 분석 | 사업성·P&L·서비스 비교 | https://docs.google.com/spreadsheets/d/1zrn0ycaBjgJQMKGxNvyjTG3FnONJYT35yXIghXYqDy8 |
| 미소방문 플래너 교육 전체 가이드_-September 2026 | Planner 교육 | https://docs.google.com/presentation/d/1H6Rp3tOFwML49sOW7-cBPZwO5Ft01xspsAbhXP8rGTE |
| Planner_metrics | Planner 생산성·성과 | https://docs.google.com/spreadsheets/d/1upVh8k1Vm2AUVAg9CZE74jHpR8GsRgNhTZQ5bcyevD8 |
| JD 정리 | 채용·역할 설계 | https://docs.google.com/spreadsheets/d/1kXTSfBUnpfjzckt-QV6u63giXYMEqJOrmRVP0p292Xc |
| [미소방문] Planner 현황 | 현재 Planner 인원·상태 | https://docs.google.com/spreadsheets/d/1LwBeWsQe7qfWqMpcrFP1BX75A7Q6Nx8vhfgUfrbi7tg |
| Moving_Conciege_Sync | R&R·운영 의사결정 | https://docs.google.com/document/d/1y4d0ytvcFJm2Qa0zULkt_53I7YbFjW7_C4sams9bZ8c |
| [Moving visit] Weekly Report (official) | 공식 주간 실적 | https://docs.google.com/document/d/1I3J1rZ7z0tfveKGEfeH588s1CsUJEDhS9fzi6Aems2k |

핵심 실적의 기본 원천은 `daily number & Moving by Miso Metrics`이며, `superset` 탭을 먼저 확인합니다. 이 문서의 URL이 변경되거나 새 공식 원천이 추가되면 이 목록과 `knowledge/source-map.md`를 함께 갱신합니다.

## Slack Source

우선 채널은 `#service-moving-visit-ops`입니다. 필요에 따라 `#service-moving`, `#product-rfq`, `#service-moving-mvos-chat`, `#service-moving-mvos-log`, `#service-moving-alert`를 보조 원천으로 사용합니다.

Slack permalink를 등록할 때는 링크만 나열하지 말고 아래 메타데이터를 함께 기록합니다.

- 주제
- 원문 작성일
- 채널
- Thread 포함 여부
- 제안/질문/확정 구분
- 대체하거나 갱신한 문서

## 유지관리

원본의 숫자와 행이 바뀌는 것은 정상입니다. 이 파일은 Source의 위치·역할·우선순위가 바뀔 때만 수정합니다.
